let balance = parseFloat(localStorage.getItem('balance')) || 0;

const balanceEl = document.getElementById('balance');
const depositModal = document.getElementById('deposit-modal');
const withdrawModal = document.getElementById('withdraw-modal');

// Para yatırma inputlar
const depositFullNameInput = document.getElementById('deposit-full-name');
const depositCardNumberInput = document.getElementById('deposit-card-number');
const depositCVVInput = document.getElementById('deposit-cvv');
const depositCVV2Input = document.getElementById('deposit-cvv2');
const depositAmountInput = document.getElementById('deposit-amount');

// Para çekme inputlar
const fullNameInput = document.getElementById('full-name');
const withdrawCardNumberInput = document.getElementById('withdraw-card-number');
const withdrawCVVInput = document.getElementById('withdraw-cvv');
const withdrawCVV2Input = document.getElementById('withdraw-cvv2');
const withdrawAmountInput = document.getElementById('withdraw-amount');

const depositButton = document.getElementById('deposit');
const withdrawButton = document.getElementById('withdraw');
const confirmDepositButton = document.getElementById('confirm-deposit');
const confirmWithdrawButton = document.getElementById('confirm-withdraw');

function updateUI() {
    balanceEl.textContent = balance.toFixed(2);
    localStorage.setItem('balance', balance);
}

depositButton.addEventListener('click', () => {
    depositModal.classList.remove('hidden');
});

confirmDepositButton.addEventListener('click', () => {
    const fullName = depositFullNameInput.value.trim();
    const cardNumber = depositCardNumberInput.value.trim();
    const cvv = depositCVVInput.value.trim();
    const cvv2 = depositCVV2Input.value.trim();
    const depositAmount = parseFloat(depositAmountInput.value);

    if (!fullName || cardNumber.length !== 16 || cvv.length !== 3 || !/^\d{2}\/\d{2}$/.test(cvv2) || depositAmount <= 0) {
        alert('Lütfen tüm bilgileri doğru şekilde doldurun!');
        return;
    }

    balance += depositAmount;
    alert(`${depositAmount} $ başarıyla yatırıldı!`);
    depositModal.classList.add('hidden');
    updateUI();
});

withdrawButton.addEventListener('click', () => {
    withdrawModal.classList.remove('hidden');
});

confirmWithdrawButton.addEventListener('click', () => {
    const fullName = fullNameInput.value.trim();
    const cardNumber = withdrawCardNumberInput.value.trim();
    const cvv = withdrawCVVInput.value.trim();
    const cvv2 = withdrawCVV2Input.value.trim();
    const withdrawAmount = parseFloat(withdrawAmountInput.value);

    if (!fullName || cardNumber.length !== 16 || cvv.length !== 3 || !/^\d{2}\/\d{2}$/.test(cvv2) || withdrawAmount <= 0) {
        alert('Lütfen tüm bilgileri doğru şekilde doldurun!');
        return;
    }

    if (withdrawAmount > balance) {
        alert('Yeterli bakiye yok!');
        return;
    }

    balance -= withdrawAmount;
    alert(`${withdrawAmount} $ başarıyla çekildi!`);
    withdrawModal.classList.add('hidden');
    updateUI();
});

updateUI();